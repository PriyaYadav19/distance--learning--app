var RNFS = require('react-native-fs');

//hkShopee= '#980303'
//jobz = '#006AA9'
//pcombinator = '#980303'

export var appVersion="1.0.0";
//server
export const BASE_URL='http://atscomm.vtsapps.com/atscommServices/api/atscomm/capp/'

//local
export var appName="Ats Institute";
//export const BASE_URL='http://192.168.31.127:8080/ATS-commservicesjdbc/api/atscomm/capp/'

//export const BASE_URL='http://192.168.42.202:8080/ATS-commservicesjdbc/api/atscomm/capp/'


export const PACKAGE='com.vts.atsinstitute';
export const BUCKET_NAME='atscommimages';
export const KEY_PREFIX="atsinstitue-docs/";
export const ACCESS_KEY='AKIAJPRJHMBUMIHDEYVQ';
export const SECRET_KEY='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';
export const REGION='us-west-2';
export var deviceId=null;
export var googleMessageIds=[];
export var rootDirectory=RNFS.ExternalStorageDirectoryPath;
export var directory='/.AtsInstitute'
export var aboutUsDirectory='/.about-us'
export var galleryDirectory='/.attachments'
export var attachmentDirectory='/.attachments'
export var profileDirectory='/.profile-pic'
export var temp='/.temp'
//export var color='#980303'
export var color='#c0011c'
export var paymentURL='https://www.instamojo.com/@IIMSSDE'

export const USER_LOGOUT="USER_LOGOUT";
export const LOGOUT="logout";
export const USER_DATA="USER_DATA";
export const GET_LIKED="userResponse";
export const LOGINURL="login";
export const VERSION_CHECK="getAppVersion";
export const CHANGE_PASSWORD="changePassword";
export const GUSET_LOGIN="userSignUp";
export const ENQUIRY="enquiry";
export const REGISTER_FCM="fcmRegistration";
export const GET_FOLDER_LIST="getFolderList";
export const GET_FOLDER_MESSAGES="getFolderMessages";
export const GET_MESSAGE_DETAILS="getMessageDetails";
export const GET_ABOUT_US="getAboutUs";
export const GET_GALLERY="getImagesList";
export const GET_CONTACT_US="getContactDetails";
export const GET_FILTER="loadMsgCategory1";
export const FEEDBACK="feedback";
export const LOAD_PROGRAMS="loadCategoryTypes";
export const LOAD_CATEGORY="loadCategory";
export const TEST="TEST";
export const STORED_NAVIGATION="STORED_NAVIGATION";
export const FORGOT_PASSWORD="forgotpassword";







