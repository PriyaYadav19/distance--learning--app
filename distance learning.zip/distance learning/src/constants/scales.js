import {Dimensions,Platform} from 'react-native';

const {width, height} = Dimensions.get('window');

function gcd(a,b) {
    if(b>a) {
        var  temp = a; a = b; b = temp
    }
    while(b!=0) {
        var  m=a%b; a=b; b=m;
    }
    return a;
}

function ratioCal(x,y) {
    var c=gcd(x,y);
    return ""+(x/c)+":"+(y/c)
}

//Guideline sizes are based on standard ~5" screen mobile device
var guidelineBaseWidth=0
if(width<350){
    guidelineBaseWidth = 316;
}
/*else if(width>=600){
    guidelineBaseWidth = 420;
}*/
else{
    if(Platform.OS=='ios')
        guidelineBaseWidth = 355;
    else
        guidelineBaseWidth = 350;
}


const guidelineBaseHeight = 680;

const ratio =()=>ratioCal(width,height);
const scale = size => Platform.OS=='ios'?parseInt(width / guidelineBaseWidth * size):width / guidelineBaseWidth * size;
const verticalScale = size => height / guidelineBaseHeight * size;
const moderateScale = (size, factor = 0.5) => size + ( scale(size) - size ) * factor;

export {scale, verticalScale, moderateScale,ratio};