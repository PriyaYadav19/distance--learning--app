import React from "react";
import {
    Platform, StyleSheet, Text, View,
    ImageBackground, Dimensions, TextInput,
    SafeAreaView, Animated, Easing, Image, TouchableOpacity,
    ScrollView
} from 'react-native';
import * as types from "../constants/actions";
import {scale} from "../constants/scales";
import {withNavigation} from "react-navigation";
import BottomNavigation from "react-native-bottom-navigation"
import {Column as Col, Row} from 'react-native-flexbox-grid';
import {backgroundColor} from 'react-native-calendars/src/style';


class TabBar extends React.Component {
    static navigationOptions = ({navigation}) => ({
        header: null,
    });

    constructor(props) {
        super(props);
        this.state = {


        };
    }

    _navigatePage = (index) => {
        console.log("Index of bottom navigator ==>> " + index);
        switch (index) {
            case 0:
                this.props.navigation.navigate('Dashboard');
                break;
            case 1:
                this.props.navigation.navigate('Ebook');
                break;
            case 2:
                this.props.navigation.navigate('Syllabus');
                break;
            default:
                this.props.navigation.navigate('Dashboard');
        }

    };

    render() {
        return (

            <BottomNavigation
                style={styles.container}
                activeColor='#fe4d52'
                inactiveColor="rgb(0, 100, 125)"
                onChangeTab={(data) => {
                    this._navigatePage(data.i)
                }}>





                <TouchableOpacity
                    //onPress={this.props.navigation.navigate('Dashboard')}
                    tabLabel="Home"
                    tabIcon={require('../images/home.png')}
                />




                <TouchableOpacity
                    tabLabel="Setting"
                    tabIcon={require('../images/setting.png')}/>


                    <TouchableOpacity
                    tabLabel="AboutUs"
                    tabIcon={require('../images/menu.png')}/>
            </BottomNavigation>


        )
    }
}

export default withNavigation(TabBar);

const styles = StyleSheet.create({

        container:
            {

            }
    }
);
