import React, {Component} from 'react';
import {
    View,Text,Image,ImageBackground,ScrollView,
    StyleSheet,TextInput,TouchableOpacity
}
    from 'react-native';
import {Column as Col, Row} from "react-native-flexbox-grid";
import {scale} from "../constants/scales";
import * as types from '../constants/actions'





class Login extends Component {
    static navigationOptions = ({navigation}) => ({
        header: null,
    });

    constructor(props) {
        super(props);
        this.state = {};
    }

    render() {
        return (


            <View style={{flex: 1,backgroundColor:'blue'}}>



                <View style={{width:scale(50),height:scale(350),backgroundColor:'#fff',borderTopRightRadius:scale(15),borderTopLeftRadius:scale(15),marginTop:scale(0)}}>
                    <Row size={12}>


                        <Col sm={12} md={12} lg={12} >
                    <Text
                        style={{color:'#000', fontWeight:'normal',textAlign:'center',
                            fontSize: scale(15),marginTop:scale(30) ,transform:[{rotate:'-270deg'
                            }]  }}>
                        LOGIN
                    </Text>

                    <Text
                        style={{color:'#000', fontWeight:'normal',textAlign:'center',
                            fontSize: scale(15),marginTop:scale(30) ,transform:[{rotate:'-270deg'
                            }]  }}>
                        SiGN  UP
                    </Text>

                    <Text
                        style={{color:'#000', fontWeight:'normal',justifyContent: 'space-around',textAlign:'center',
                            fontSize: scale(15),marginTop:scale(20) ,transform:[{rotate:'-270deg' ,
                            }]  }}>
                        FORGOT PASSWORD
                    </Text>


</Col>
                    </Row>
                </View>

<View style={{width:'80%',height:'45%',backgroundColor:'#fff',marginTop:scale(-95),borderTopRightRadius:scale(20),borderBottomRightRadius:scale(20)}}>
    <Text
        style={{color:'#000', fontWeight:'normal',
            fontSize: scale(15),marginTop:scale(10),marginLeft:scale(80)}}>
        LOGIN
    </Text>




    <View
        style={styles.colText}>
        <View>
            <TextInput placeholderTextColor='#000' secureTextEntry={true}
                       ref="password"
                       placeholderStyle={styles.placeholder}
                       onBlur={() => {
                           this.showLine()
                       }}
                       onFocus={() => {
                           this.hideLine();
                           this.setState({errorPasword: ''})
                       }}
                       returnKeyType="done"
                       onChangeText={(text) => {
                           this.setState({password: text})
                       }}
                // onSubmitEditing={()=>{this.validation()}}
                       value={this.state.password}
                       placeholder="Name"
                       underlineColorAndroid='transparent'
                       style={{margin:Platform.OS=='ios'?scale(10):0,
                           paddingLeft:scale(10)}}
            >

            </TextInput>
        </View>
    </View>

    <View
        style={styles.colText}>
        <View>
            <TextInput placeholderTextColor='#000' secureTextEntry={true}
                       ref="password"
                       placeholderStyle={styles.placeholder}
                       onBlur={() => {
                           this.showLine()
                       }}
                       onFocus={() => {
                           this.hideLine();
                           this.setState({errorPasword: ''})
                       }}
                       returnKeyType="done"
                       onChangeText={(text) => {
                           this.setState({password: text})
                       }}
                // onSubmitEditing={()=>{this.validation()}}
                       value={this.state.password}
                       placeholder="Password"
                       underlineColorAndroid='transparent'
                       style={{margin:Platform.OS=='ios'?scale(10):0,
                           paddingLeft:scale(10)}}
            >

            </TextInput>
        </View>
    </View>



    <Row size={12}>


        <Col sm={2} md={2} lg={2}>
            <View style={{flexDirection:'row',alignItems:'center', marginTop: scale(30),}}>
                <Image source={require('../images/circle.png')}

                       resizeMode='contain'
                       style={{height: scale(20),
                           width: scale(20),marginLeft:scale(70),margin:Platform.OS=='ios'?scale(10):0}}
                />

            </View>
        </Col>
        <Col sm={10} md={10} lg={10} style={{alignItems: 'center'}}>
            <View style={{alignItems: 'center', marginTop: scale(30),
                fontWeight: 'bold',fontSize:scale(50)}}>
                <TouchableOpacity

                    onPress={ () => this.props.navigation.navigate('Forgotpassword')}
                />
                    <TouchableOpacity

                    onPress={ () => this.props.navigation.navigate('Forgotpassword')}
                >
                    <Text style={{ color:'#000',fontSize:scale(15),marginLeft: scale(2)}}>
                        SAVE PASSWORD
                    </Text>
                </TouchableOpacity>
            </View>
        </Col>

        <Col sm={2} md={2} lg={2}>
            <View style={{flexDirection:'row',alignItems:'center', marginTop: scale(10),}}>
                <TouchableOpacity

                    onPress={ () => this.props.navigation.navigate('Dashboard') }>
                <Image source={require('../images/right-arrow.png')}

                       resizeMode='contain'
                       style={{height: scale(30),
                           width: scale(30),marginLeft:scale(60),margin:Platform.OS=='ios'?scale(10):0}}
                />
                </TouchableOpacity>
            </View>
        </Col>
    </Row>

</View>

                <View style={{width:scale(40),height:scale(90),backgroundColor:'#fff',borderBottomRightRadius:scale(15),marginTop:scale(0)}}>

                </View>


                {/*<Row size={12} style={{marginTop:scale(20)}}>
                    <Col sm={4} md={4} lg={4} style={{alignItems:'center'}}>
                        <View style={[styles.View,{backgroundColor:"#fff",borderWidth:scale(0.2)}]}>

                            <TouchableOpacity

                                onPress={ () => this.props.navigation.navigate('Login')}
                            >
                                <Text
                                    style={{color:types.color, fontWeight:'normal',textAlign:'center',
                                        fontSize: scale(15),marginTop:scale(0)}}>
                                    LOGIN
                                </Text>
                            </TouchableOpacity>
                        </View>
                    </Col>
                    <Col sm={4} md={4} lg={4} style={{alignItems:'center',}}>
                        <View style={[styles.View,{backgroundColor:types.color,}]}>

                            <TouchableOpacity

                                onPress={ () => this.props.navigation.navigate('Signup')}
                            >
                                <Text
                                    style={{color:"#fff", fontWeight:'normal',
                                        fontSize: scale(15),marginTop:scale(0)}}>
                                    SIGN UP
                                </Text>
                            </TouchableOpacity>
                        </View>
                    </Col>


                    <Col sm={4} md={4} lg={4} style={{alignItems:'center',transform: [{rotate:300}]}}>
                        <View style={[styles.View,{backgroundColor:types.color,}]}>

                            <TouchableOpacity

                                onPress={ () => this.props.navigation.navigate('Forgotpassword')}
                            >
                                <Text
                                    style={{color:"#fff", fontWeight:'normal',
                                        fontSize: scale(15),marginTop:scale(0)}}>
                                    FORGOT PASSWORD
                                </Text>
                            </TouchableOpacity>
                        </View>
                    </Col>
                </Row>


<View style={styles.box}>

                <View style={{marginTop: scale(40),alignItems:'center',

                }}>

                    <View
                        style={styles.colText}>
                        <View>
                            <TextInput placeholderTextColor='#000' secureTextEntry={true}
                                       ref="password"
                                       placeholderStyle={styles.placeholder}
                                       onBlur={() => {
                                           this.showLine()
                                       }}
                                       onFocus={() => {
                                           this.hideLine();
                                           this.setState({errorPasword: ''})
                                       }}
                                       returnKeyType="done"
                                       onChangeText={(text) => {
                                           this.setState({password: text})
                                       }}
                                // onSubmitEditing={()=>{this.validation()}}
                                       value={this.state.password}
                                       placeholder="Name"
                                       underlineColorAndroid='transparent'
                                       style={{margin:Platform.OS=='ios'?scale(10):0,
                                           paddingLeft:scale(10)}}
                            >

                            </TextInput>
                        </View>
                    </View>
                </View>





                <View style={{marginTop: scale(40),alignItems:'center',

                }}>

                    <View
                        style={styles.colText}>
                        <View>
                            <TextInput placeholderTextColor='#000' secureTextEntry={true}
                                       ref="password"
                                       placeholderStyle={styles.placeholder}
                                       onBlur={() => {
                                           this.showLine()
                                       }}
                                       onFocus={() => {
                                           this.hideLine();
                                           this.setState({errorPasword: ''})
                                       }}
                                       returnKeyType="done"
                                       onChangeText={(text) => {
                                           this.setState({password: text})
                                       }}
                                // onSubmitEditing={()=>{this.validation()}}
                                       value={this.state.password}
                                       placeholder="Password"
                                       underlineColorAndroid='transparent'
                                       style={{margin:Platform.OS=='ios'?scale(10):0,
                                           paddingLeft:scale(10)}}
                            >

                            </TextInput>
                        </View>
                    </View>
                </View>
                <Row size={12}>


                    <Col sm={2} md={2} lg={2}>
                        <View style={{flexDirection:'row',alignItems:'center', marginTop: scale(35),}}>
                            <Image source={require('../images/circle.png')}

                                   resizeMode='contain'
                                   style={{height: scale(20),
                                       width: scale(20),marginLeft:scale(10),margin:Platform.OS=='ios'?scale(10):0}}
                            />

                        </View>
                    </Col>
                    <Col sm={10} md={10} lg={10} style={{alignItems: 'center'}}>
                        <View style={{alignItems: 'center', marginTop: scale(30),
                            fontWeight: 'bold',fontSize:scale(50)}}>
                            <TouchableOpacity

                                onPress={ () => this.props.navigation.navigate('Forgotpassword')}
                            >
                                <Text style={{ color:'#000',fontSize:scale(15),marginLeft: scale(2)}}>
                                    SAVE PASSWORD
                                </Text>
                            </TouchableOpacity>
                        </View>
                    </Col>


                </Row>
*/}
                {/*<View
                    style={{justifyContent:'center',
                        marginTop: scale(5),
                        alignItems: 'center',}}>

                    <TouchableOpacity
                        style={{height:'30%',width:'88%',borderRadius:scale(10),
                            backgroundColor:types.color,}}
                        onPress={ () => this.props.navigation.navigate('Welcome')}
                    >

                        <Text style={{fontSize:scale(15),color:'#fff' ,
                            marginTop:scale(12),
                            opacity: scale(1.6),textAlign: 'center',
                        }}>
                            CONTINUE
                        </Text>
                    </TouchableOpacity>
                </View>*/}



            </View>
        )
    }
}
export default Login;

const styles = StyleSheet.create({

    colText: {
        width:'65%',
        backgroundColor: 'rgba(255,255,255,0.8)',
        borderRadius: 15,
        borderColor:"#b7b7b7",
        borderWidth:0.5,
        height:scale(45),
        marginLeft:scale(60),
marginTop:scale(20)
    },
    View:{
        width:'55%',
        height:'25%',
        justifyContent:'center',
        marginTop:scale(5),
        borderRadius:scale(10),
        alignItems:'center'
    },
    placeholder:{
        fontWeight:'bold',
    },

box:{
    width:'65%',
    backgroundColor: 'rgba(255,255,255,0.8)',
    borderRadius: 15,
    borderColor:"#b7b7b7",
    borderWidth:0.5,
    height:scale(300),
    marginLeft:scale(60),
    marginTop: scale(150)
},
col:{
    width:'65%',
    backgroundColor: 'rgba(255,255,255,0.8)',
    borderRadius: 15,
    borderColor:"#b7b7b7",
    borderWidth:0.5,
    marginTop:scale(-20),
    marginLeft: scale(-110),
    height:scale(45),
transform:[{
        rotate:300
}]
}
});
