import React, {Component} from 'react';
import {
    View,Text,Image,ImageBackground,ScrollView,
    StyleSheet,TextInput,TouchableOpacity
}
    from 'react-native';
import {Column as Col, Row} from "react-native-flexbox-grid";
import {scale} from "../constants/scales";
import * as types from '../constants/actions'





class Calender extends Component {
    static navigationOptions = ({navigation}) => ({
        header: null,
    });

    constructor(props) {
        super(props);
        this.state = {};
    }

    render() {
        return (
            <View style={{flex: 1,backgroundColor:'blue'}}>


            </View>
        )
    }
}
export default Calender;