import React, {Component} from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  Image,
  StyleSheet,
  ScrollView,
} from 'react-native';
import {Column as Col, Row} from 'react-native-flexbox-grid';
import {scale} from '../constants/scales';
import * as types from '../constants/actions';
import TabBar from '../components/tabBar';

class Events extends Component {
  static navigationOptions = ({navigation}) => ({
    header: null,
  });
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <View style={{flex: 1}}>
        <View
          style={{
            backgroundColor: '#35CCFF',
            height: scale(50),
            width: '100%',
          }}>
          <Row size={12} style={{marginTop: scale(15)}}>
            <Col sm={2} md={2} lg={2} style={{alignItems: 'center'}}>
              <TouchableOpacity
                onPress={() => this.props.navigation.navigate('Ebook')}>
                <Image
                  source={require('../images/back-arrow.png')}
                  style={{
                    height: scale(20),
                    width: scale(20),
                    marginTop: scale(5),
                    tintColor: '#fff',
                  }}
                />
              </TouchableOpacity>
            </Col>
            <Col sm={8} md={8} lg={8} style={{alignItems: 'center'}}>
              <View
                style={{
                  margin: scale(5),
                  borderRadius: scale(18),
                  alignItems: 'center',
                  marginTop: scale(5),
                }}>
                <Text
                  style={{
                    color: '#fff',
                    fontWeight: 'normal',
                    fontSize: scale(20),
                    marginLeft: scale(80),
                  }}>
                  EVENTS{' '}
                </Text>
              </View>
            </Col>

            <Col sm={2} md={2} lg={2} style={{alignItems: 'center'}}>
              <TouchableOpacity
                onPress={() => this.props.navigation.navigate('SignIn')}>
                <Image
                  source={require('../images/magnifier.png')}
                  style={{
                    height: scale(20),
                    width: scale(20),
                    marginTop: scale(5),
                  }}
                />
              </TouchableOpacity>
            </Col>
          </Row>
        </View>
        <View style={styles.FolderIcon}>
          <Text
            style={{
              color: '#3BEBFF',
              fontWeight: 'normal',
              fontSize: scale(20),
              marginLeft: scale(50),
              marginTop: scale(5),
            }}>
            Management Science
          </Text>

          <View>
            <Text style={{marginLeft: scale(10), marginTop: scale(10)}}>
              The regular technical school or college aims to educate a man
              broadly; our aim is to educate him only along some particular
              line.
            </Text>
          </View>

          <Row
            size={12}
            style={{
              marginTop: scale(3),
              marginLeft: scale(250),
            }}>
            <Col sm={2} md={2} lg={2} style={{}}>
              <View>
                <Image
                  style={{
                    height: scale(22),
                    width: scale(22),
                    tintColor: '#000',
                  }}
                  source={require('../images/share.png')}
                />
              </View>
            </Col>
          </Row>
        </View>

        <View style={styles.FolderIcon}>
          <Text
            style={{
              color: '#3BEBFF',
              fontWeight: 'normal',
              fontSize: scale(20),
              marginLeft: scale(30),
              marginTop: scale(5),
            }}>
            Accounting for management
          </Text>
          <View>
            <Text style={{marginLeft: scale(10), marginTop: scale(10)}}>
              The regular technical school or college aims to educate a man
              broadly; our aim is to educate him only along some particular
              line.
            </Text>
          </View>

          <Row
            size={12}
            style={{
              marginTop: scale(3),
              marginLeft: scale(250),
            }}>
            <Col sm={2} md={2} lg={2} style={{}}>
              <View>
                <Image
                  style={{
                    height: scale(22),
                    width: scale(22),
                    tintColor: '#000',
                  }}
                  source={require('../images/share.png')}
                />
              </View>
            </Col>
          </Row>
        </View>

        <View style={styles.FolderIcon}>
          <Text
            style={{
              color: '#3BEBFF',
              fontWeight: 'normal',
              fontSize: scale(20),
              marginLeft: scale(50),
              marginTop: scale(5),
            }}>
            Buisness environment{' '}
          </Text>
          <View>
            <Text style={{marginLeft: scale(10), marginTop: scale(10)}}>
              The regular technical school or college aims to educate a man
              broadly; our aim is to educate him only along some particular
              line.
            </Text>
          </View>

          <Row
            size={12}
            style={{
              marginTop: scale(4),
              marginLeft: scale(250),
            }}>
            <Col sm={2} md={2} lg={2} style={{}}>
              <View>
                <Image
                  style={{
                    height: scale(22),
                    width: scale(22),
                    tintColor: '#000',
                  }}
                  source={require('../images/share.png')}
                />
              </View>
            </Col>
          </Row>
        </View>

        <View
          style={{
            justifyContent: 'flex-end',
            flexDirection: 'row',
            alignItems: 'flex-end',
            flex: 1,
          }}>
          <TabBar />
        </View>
      </View>
    );
  }
}

export default Events;
const styles = StyleSheet.create({
  FolderIcon: {
    height: scale(120),
    width: scale(300),
    margin: Platform.OS == 'ios' ? scale(10) : 0,
    backgroundColor: '#fff',
    borderRadius: scale(10),
    marginLeft: scale(20),
    marginTop: scale(20),
  },
});
