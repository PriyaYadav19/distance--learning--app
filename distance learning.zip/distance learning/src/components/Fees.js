import React,{Component} from  'react';
import {Text, View, TouchableOpacity, Image, StyleSheet,ScrollView} from 'react-native';
import {Column as Col, Row} from "react-native-flexbox-grid";
import {scale} from "../constants/scales";
import * as types from '../constants/actions'
import TabBar from '../components/tabBar';

class Fees extends Component{

    static navigationOptions = ({navigation}) => ({
        header: null,
    });
    constructor(props){
        super(props);
        this.state={};
    }

    render(){
        return(

<View style={{flex:1}}>
            <View style={{backgroundColor:'#35CCFF',height:scale(50),width:'100%',}}>

                <Row size={12} style={{marginTop:scale(15)}}>
                    <Col sm={2} md={2} lg={2} style={{alignItems:'center'}}>
                        <TouchableOpacity
                            onPress={() => this.props.navigation.navigate('Ebook')}
                        >
                            <Image source={require('../images/back-arrow.png')}
                                   style={{height:scale(20),width:scale(20),marginTop:scale(5),tintColor: '#fff'}}/>
                        </TouchableOpacity>
                    </Col>
                    <Col sm={8} md={8} lg={8} style={{alignItems:'center'}}>

                        <View style={{
                            margin:scale(5),
                            borderRadius:scale(18),alignItems:'center',marginTop:scale(5),}}>
                            <Text
                                style={{color:"#fff", fontWeight: 'normal',
                                    fontSize: scale(20),marginLeft:scale(80)}}>
                                FEES                          </Text>

                        </View>
                    </Col>




                    <Col sm={2} md={2} lg={2} style={{alignItems:'center'}}>
                        <TouchableOpacity
                            onPress={() => this.props.navigation.navigate('SignIn')}
                        >
                            <Image source={require('../images/magnifier.png')}
                                   style={{height:scale(20),width:scale(20),marginTop:scale(5)}}/>
                        </TouchableOpacity>
                    </Col>
                </Row>
            </View>
                <View style={styles.FolderIcon} >
                    <Text
                        style={{color:"#3BEBFF", fontWeight: 'normal',
                            fontSize: scale(15),marginLeft:scale(5),marginTop:scale(5)}}>
                        Master in  Buisness Administration                         </Text>


                    <Row size={12} style={{
                        marginTop: scale(10),
                        marginLeft:scale(20)
                    }}>
                        <Col sm={4} md={4} lg={4} style={{

                        }}>

                            <View>
                                <Text
                                    style={{color:"#3BEBFF", fontWeight: 'normal',
                                        fontSize: scale(10),marginLeft:scale(5),marginTop:scale(5)}}>
                                    Course Type                       </Text>

                            </View>
                            <View>
                                <Text
                                    style={{color:"#3BEBFF", fontWeight: 'normal',
                                        fontSize: scale(10),marginLeft:scale(5),marginTop:scale(5)}}>
                                    Tuition Fees                       </Text>

                            </View>
                            <View>
                                <Text
                                    style={{color:"#3BEBFF", fontWeight: 'normal',
                                        fontSize: scale(10),marginLeft:scale(5),marginTop:scale(5)}}>
                                    Duration                       </Text>

                            </View>

                            <View>
                                <Text
                                    style={{color:"#3BEBFF", fontWeight: 'normal',
                                        fontSize: scale(10),marginLeft:scale(5),marginTop:scale(5)}}>
                                    Total Seats                      </Text>

                            </View>

                        </Col>


                        <Col sm={8} md={8} lg={8} style={{

                        }}>

                            <View>
                                <Text
                                    style={{color:"#3BEBFF", fontWeight: 'normal',
                                        fontSize: scale(12),marginLeft:scale(0),marginTop:scale(2)}}>
                                MBA/PGDM
                                </Text>
                            </View>
                            <View>
                                <Text
                                    style={{color:"#3BEBFF", fontWeight: 'normal',
                                        fontSize: scale(12),marginLeft:scale(0),marginTop:scale(2)}}>
                                    INR 20,50,00
                                </Text>
                            </View>
                            <View>
                                <Text
                                    style={{color:"#3BEBFF", fontWeight: 'normal',
                                        fontSize: scale(12),marginLeft:scale(0),marginTop:scale(2)}}>24 Months
                                </Text>
                            </View>

                            <View>
                                <Text
                                    style={{color:"#3BEBFF", fontWeight: 'normal',
                                        fontSize: scale(12),marginLeft:scale(0),marginTop:scale(2)}}>180
                                </Text>
                            </View>



                        </Col>



                    </Row>
                    <Row size={12} style={{
                        marginTop: scale(-110),
                        marginLeft:scale(250)
                    }}>
                        <Col sm={4} md={4} lg={4} style={{

                        }}>

                            <View>
                                <Image style={{
                                    height: scale(20),
                                    width: scale(20),
                                    tintColor:'#000'
                                }} source={require('../images/share.png')}/>

                            </View>

                        </Col>


                    </Row>



                </View>


                <View style={styles.FolderIcon} >

                    <Text
                        style={{color:"#3BEBFF", fontWeight: 'normal',
                            fontSize: scale(20),marginLeft:scale(10),marginTop:scale(5)}}>
                        Accounting  for management</Text>
                    <Row size={12} style={{
                        marginTop: scale(10),
                        marginLeft:scale(20)
                    }}>
                        <Col sm={4} md={4} lg={4} style={{

                        }}>

                            <View>
                                <Text
                                    style={{color:"#3BEBFF", fontWeight: 'normal',
                                        fontSize: scale(10),marginLeft:scale(5),marginTop:scale(5)}}>
                                    Course Type                       </Text>

                            </View>
                            <View>
                                <Text
                                    style={{color:"#3BEBFF", fontWeight: 'normal',
                                        fontSize: scale(10),marginLeft:scale(5),marginTop:scale(5)}}>
                                    Tuition Fees                       </Text>

                            </View>
                            <View>
                                <Text
                                    style={{color:"#3BEBFF", fontWeight: 'normal',
                                        fontSize: scale(10),marginLeft:scale(5),marginTop:scale(5)}}>
                                    Duration                       </Text>

                            </View>

                            <View>
                                <Text
                                    style={{color:"#3BEBFF", fontWeight: 'normal',
                                        fontSize: scale(10),marginLeft:scale(5),marginTop:scale(5)}}>
                                    Total Seats                      </Text>

                            </View>

                        </Col>


                        <Col sm={8} md={8} lg={8} style={{

                        }}>

                            <View>
                                <Text
                                    style={{color:"#3BEBFF", fontWeight: 'normal',
                                        fontSize: scale(12),marginLeft:scale(0),marginTop:scale(2)}}>
                                    MBA/PGDM
                                </Text>
                            </View>
                            <View>
                                <Text
                                    style={{color:"#3BEBFF", fontWeight: 'normal',
                                        fontSize: scale(12),marginLeft:scale(0),marginTop:scale(2)}}>
                                    INR 20,50,00
                                </Text>
                            </View>
                            <View>
                                <Text
                                    style={{color:"#3BEBFF", fontWeight: 'normal',
                                        fontSize: scale(12),marginLeft:scale(0),marginTop:scale(2)}}>24 Months
                                </Text>
                            </View>

                            <View>
                                <Text
                                    style={{color:"#3BEBFF", fontWeight: 'normal',
                                        fontSize: scale(12),marginLeft:scale(0),marginTop:scale(2)}}>180
                                </Text>
                            </View>



                        </Col>



                    </Row>
                    <Row size={12} style={{
                        marginTop: scale(-110),
                        marginLeft:scale(275)
                    }}>
                        <Col sm={2} md={2} lg={2} style={{

                        }}>

                            <View>
                                <Image style={{
                                    height: scale(20),
                                    width: scale(20),
                                    tintColor:'#000'
                                }} source={require('../images/share.png')}/>

                            </View>

                        </Col>


                    </Row>
                </View>

                <View style={styles.FolderIcon} >

                    <Text
                        style={{color:"#3BEBFF", fontWeight: 'normal',
                            fontSize: scale(20),marginLeft:scale(10),marginTop:scale(5)}}>
                        Buisness environment                         </Text>




                    <Row size={12} style={{
                        marginTop: scale(10),
                        marginLeft:scale(20)
                    }}>
                        <Col sm={4} md={4} lg={4} style={{

                        }}>

                            <View>
                                <Text
                                    style={{color:"#3BEBFF", fontWeight: 'normal',
                                        fontSize: scale(10),marginLeft:scale(5),marginTop:scale(5)}}>
                                    Course Type                       </Text>

                            </View>
                            <View>
                                <Text
                                    style={{color:"#3BEBFF", fontWeight: 'normal',
                                        fontSize: scale(10),marginLeft:scale(5),marginTop:scale(5)}}>
                                    Tuition Fees                       </Text>

                            </View>
                            <View>
                                <Text
                                    style={{color:"#3BEBFF", fontWeight: 'normal',
                                        fontSize: scale(10),marginLeft:scale(5),marginTop:scale(5)}}>
                                    Duration                       </Text>

                            </View>

                            <View>
                                <Text
                                    style={{color:"#3BEBFF", fontWeight: 'normal',
                                        fontSize: scale(10),marginLeft:scale(5),marginTop:scale(5)}}>
                                    Total Seats                      </Text>

                            </View>

                        </Col>


                        <Col sm={8} md={8} lg={8} style={{

                        }}>

                            <View>
                                <Text
                                    style={{color:"#3BEBFF", fontWeight: 'normal',
                                        fontSize: scale(12),marginLeft:scale(0),marginTop:scale(2)}}>
                                    MBA/PGDM
                                </Text>
                            </View>
                            <View>
                                <Text
                                    style={{color:"#3BEBFF", fontWeight: 'normal',
                                        fontSize: scale(12),marginLeft:scale(0),marginTop:scale(2)}}>
                                    INR 20,50,00
                                </Text>
                            </View>
                            <View>
                                <Text
                                    style={{color:"#3BEBFF", fontWeight: 'normal',
                                        fontSize: scale(12),marginLeft:scale(0),marginTop:scale(2)}}>24 Months
                                </Text>
                            </View>

                            <View>
                                <Text
                                    style={{color:"#3BEBFF", fontWeight: 'normal',
                                        fontSize: scale(12),marginLeft:scale(0),marginTop:scale(2)}}>180
                                </Text>
                            </View>



                        </Col>



                    </Row>

                    <Row size={12} style={{
                        marginTop: scale(-110),
                        marginLeft:scale(250)
                    }}>
                        <Col sm={2} md={2} lg={2} style={{

                        }}>

                            <View>
                                <Image style={{
                                    height: scale(20),
                                    width: scale(20),
                                    tintColor:'#000'
                                }} source={require('../images/share.png')}/>

                            </View>

                        </Col>


                    </Row>
                </View>



                <View style={{justifyContent:'flex-end',flexDirection:'row',alignItems:'flex-end',flex:1,
                }}>

                    <TabBar />

                </View>







            </View>
        )

    }



}

export default Fees;
const styles = StyleSheet.create({


        FolderIcon: {

            height: scale(120),
            width: scale(300),
            margin: Platform.OS == 'ios' ? scale(10) : 0,
            backgroundColor: '#fff',
            borderRadius:scale(10),
            marginLeft: scale(20),
            marginTop:scale(20)
        },
    }
);
