import React,{Component} from  'react';
import {Text, View, TouchableOpacity, Image, StyleSheet} from 'react-native';
import {Column as Col, Row} from "react-native-flexbox-grid";
import {scale} from "../constants/scales";
import * as types from '../constants/actions'
import TabBar from '../components/tabBar';

class Syllabus extends Component{

    static navigationOptions = ({navigation}) => ({
        header: null,
    });
    constructor(props){
        super(props);
        this.state={};
    }

    render(){
        return(


<View style={{flex:1}}>

            <View style={{backgroundColor:'#35CCFF',height:scale(50),width:'100%'}}>

                <Row size={12} style={{marginTop:scale(15)}}>
                    <Col sm={2} md={2} lg={2} style={{alignItems:'center'}}>
                        <TouchableOpacity
                            onPress={() => this.props.navigation.navigate('Dashboard')}
                        >
                            <Image source={require('../images/back-arrow.png')}
                                   style={{height:scale(20),width:scale(20),marginTop:scale(5),tintColor: '#fff'}}/>
                        </TouchableOpacity>
                    </Col>
                    <Col sm={8} md={8} lg={8} style={{alignItems:'center'}}>

                        <View style={{
                            margin:scale(5),
                            borderRadius:scale(18),alignItems:'center',marginTop:scale(5),}}>
                            <Text
                                style={{color:"#fff", fontWeight: 'normal',
                                    fontSize: scale(20),marginLeft:scale(20)}}>SYLLABUS</Text>

                        </View>
                    </Col>




                    <Col sm={2} md={2} lg={2} style={{alignItems:'center'}}>
                        <TouchableOpacity
                            onPress={() => this.props.navigation.navigate('SignIn')}
                        >
                            <Image source={require('../images/magnifier.png')}
                                   style={{height:scale(20),width:scale(20),marginTop:scale(5)}}/>
                        </TouchableOpacity>
                    </Col>
                </Row>
            </View>
<View style={styles.FolderIcon}>


    <View style={{alignItems:'center',marginTop:scale(20)
        ,margin:scale(20),height:'auto',
        paddingBottom:scale(30)
    }}>

        <View style={{
            marginTop:scale(10),
            borderBottomWidth: scale(2)
        }}>

            <Text style={{
                textAlign: 'justify', fontSize: 18,
                color: '#000', margin: scale(10),
                opacity: 1.6,
            }}>

                1.TextInput is the fundamental component to input text.
            </Text>

        </View>

        <View style={{
            marginTop:scale(10),
            borderBottomWidth: scale(2)
        }}>

            <Text style={{
                textAlign: 'justify', fontSize: 18,
                color: '#000', margin: scale(10),
                opacity: 1.6,
            }}>

                2.TextInput is the fundamental component to input text.
            </Text>

        </View>

        <View style={{
            marginTop:scale(10),
            borderBottomWidth: scale(2)
        }}>

            <Text style={{
                textAlign: 'justify', fontSize: 18,
                color: '#000', margin: scale(10),
                opacity: 1.6,
            }}>

                3.TextInput is the fundamental component to input text.
            </Text>

        </View>
        <View style={{
            marginTop:scale(10),
            borderBottomWidth: scale(2)
        }}>

            <Text style={{
                textAlign: 'justify', fontSize: 18,
                color: '#000', margin: scale(10),
                opacity: 1.6,
            }}>

                4.TextInput is the fundamental component to input text.
            </Text>

        </View>
        <View style={{
            marginTop:scale(10),
            borderBottomWidth: scale(2)
        }}>

            <Text style={{
                textAlign: 'justify', fontSize: 18,
                color: '#000', margin: scale(10),
                opacity: 1.6,
            }}>

                5.TextInput is the fundamental component to input text.
            </Text>

        </View>



        <Row size={12} style={{
            marginTop: scale(10),
            marginLeft:scale(180)
        }}>
            <Col sm={2} md={2} lg={2} style={{

            }}>

                <View>
                    <Image style={{
                        height: scale(22),
                        width: scale(22),
                        tintColor:'#000'
                    }} source={require('../images/share.png')}/>

                </View>

            </Col>


        </Row>

    </View>


</View>
                <View style={{justifyContent:'flex-end',flexDirection:'row',alignItems:'flex-end',
                }}>

                    <TabBar />

                </View>

            </View>
        )

    }



}

export default Syllabus;
const styles = StyleSheet.create({


        FolderIcon: {

            height: scale(500),
            width: scale(300),
            margin: Platform.OS == 'ios' ? scale(10) : 0,
            backgroundColor: '#fff',
            borderRadius:scale(10),
            marginLeft: scale(20),
            marginTop:scale(20)
        },





    }
);
