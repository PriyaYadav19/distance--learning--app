import React, {Component} from 'react';
import {
    View,Text,Image,ImageBackground,ScrollView,
    StyleSheet,TextInput,TouchableOpacity
}
    from 'react-native';
import * as types from '../constants/actions'
import {scale} from '../constants/scales'
import {Column as Col, Row} from 'react-native-flexbox-grid';

class SignIn extends Component{
    static navigationOptions = ({navigation}) => ( {
        header: null,
    });
    constructor(props){
        super(props);
        this.state={
            isChecked:true,
            checkedImage:require('../images/correct.png'),
            unCheckedImage:require('../images/circle.png'),
        };
    }




render() {
    return (
        <View
                         style={{
                            flex:1
                         }}>

           <View style={{flex:1}}>

            <Row size={12} style={{marginTop:scale(20)}}>
                <Col sm={6} md={6} lg={6} style={{alignItems:'center'}}>
                        <View style={[styles.View,{backgroundColor:"#fff",borderWidth:scale(0.2)}]}>

                        <TouchableOpacity

                            onPress={ () => this.props.navigation.navigate('SignIn')}
                        >
                            <Text
                                style={{color:types.color, fontWeight:'normal',textAlign:'center',
                                    fontSize: scale(15),marginTop:scale(0)}}>
                                SIGN IN
                            </Text>
                        </TouchableOpacity>
                    </View>
                </Col>
                <Col sm={6} md={6} lg={6} style={{alignItems:'center',}}>
                    <View style={[styles.View,{backgroundColor:types.color,}]}>

                    <TouchableOpacity

                            onPress={ () => this.props.navigation.navigate('Signup')}
                        >
                            <Text
                                style={{color:"#fff", fontWeight:'normal',
                                    fontSize: scale(15),marginTop:scale(0)}}>
                                SIGN UP
                            </Text>
                        </TouchableOpacity>
                    </View>
                </Col>
            </Row>

                <View style={{marginTop: scale(-50),alignItems:'center',

                }}>
                    <View
                        style={styles.colText}>
                        <View>
                            <TextInput onChangeText={(text) => {
                                this.setState({username: text})
                            }}
                                       onBlur={() => {
                                           this.showLine()
                                       }}
                                       onFocus={() => {
                                           this.hideLine();
                                           this.setState({errorUsername: ''})
                                       }}
                                       returnKeyType="next"
                                       placeholderTextColor='#000'
                                       placeholder="Name"
                                       underlineColorAndroid='transparent'
                                       keyboardType="numeric"
                                       value={this.state.username}
                                       onSubmitEditing={() => {
                                           this.refs.password.focus()
                                       }}
                                       style={{margin:Platform.OS=='ios'?scale(10):0,
                                           paddingLeft:scale(10),
                                       }}
                            >

                            </TextInput>
                        </View>
                    </View>
                </View>
                <View style={{marginTop: scale(40),alignItems:'center',

                }}>

                    <View
                        style={styles.colText}>
                        <View>
                            <TextInput placeholderTextColor='#000' secureTextEntry={true}
                                       ref="password"
                                       placeholderStyle={styles.placeholder}
                                       onBlur={() => {
                                           this.showLine()
                                       }}
                                       onFocus={() => {
                                           this.hideLine();
                                           this.setState({errorPasword: ''})
                                       }}
                                       returnKeyType="done"
                                       onChangeText={(text) => {
                                           this.setState({password: text})
                                       }}
                                // onSubmitEditing={()=>{this.validation()}}
                                       value={this.state.password}
                                       placeholder="Password"
                                       underlineColorAndroid='transparent'
                                       style={{margin:Platform.OS=='ios'?scale(10):0,
                                           paddingLeft:scale(10)}}
                            >

                            </TextInput>
                        </View>
                    </View>
                </View>
                <Row size={12}>
                    <Col sm={6} md={6} lg={6} style={{alignItems: 'center'}}>
                        <View style={{alignItems: 'center', marginTop: scale(35),
                            fontWeight: 'bold',fontSize:scale(50)}}>
                            <TouchableOpacity

                                onPress={ () => this.props.navigation.navigate('Forgotpassword')}
                            >
                            <Text style={{ color:'#000',fontSize:scale(15)}}>
                                FORGOT PASSWORD
                            </Text>
                            </TouchableOpacity>
                        </View>
                    </Col>
                    <Col sm={1} md={1} lg={1}>
                    </Col>
                    <Col sm={5} md={5} lg={5}>
                        <View style={{flexDirection:'row',alignItems:'center', marginTop: scale(35),}}>
                            <Image source={
                                this.state.isChecked?
                                    this.state.checkedImage:
                                    this.state.unCheckedImage
                            }
                                   resizeMode='contain'
                                   style={{height: scale(20), tintColor:types.color,
                                       width: scale(20),margin:Platform.OS=='ios'?scale(10):0}}
                            />
                            <Text style={{marginLeft:scale(8),fontSize:scale(13),
                                color:'#000'}}>
                                Remember me
                            </Text>
                        </View>
                    </Col>
                </Row>

                <View
                    style={{justifyContent:'center',
                        marginTop: scale(5),
                        alignItems: 'center',}}>

                    <TouchableOpacity
                        style={{height:'25%',width:'88%',borderRadius:scale(10),
                            backgroundColor:types.color,}}
                        onPress={ () => this.props.navigation.navigate('Welcome')}
                    >

                            <Text style={{fontSize:scale(15),color:'#fff' ,
                                marginTop:scale(12),
                                opacity: scale(1.6),textAlign: 'center',
                            }}>
                                CONTINUE
                            </Text>
                    </TouchableOpacity>
                </View>
           </View>
        </View>
    )
}

}
export  default  SignIn
const styles = StyleSheet.create({

    colText: {
        width:'85%',
        backgroundColor: 'rgba(255,255,255,0.8)',
        borderRadius: 15,
        borderColor:"#b7b7b7",
        borderWidth:0.5,
        height:scale(45)

    },
  View:{
        width:'55%',
        height:'25%',
justifyContent:'center',
        marginTop:scale(5),
        borderRadius:scale(10),
        alignItems:'center'
  },
    placeholder:{
        fontWeight:'bold',
    },


});
