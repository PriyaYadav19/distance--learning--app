import Api from '../utils/api'
import * as Actions from '../actions/appActions'
import * as types from '../constants/actions'
import * as SignOut from '../components/signOut'


export function fetchFolderList(req,token) {
    return (dispatch) => {
        return Api.post(types.GET_FOLDER_LIST, req, token).then(resp => {
            dispatch(Actions.setFolderList({resp: resp}));
        }).catch((ex) => {
        });
    }
}

export function fetchFolderMessages(req,token) {
    return (dispatch) => {
        return Api.post(types.GET_FOLDER_MESSAGES, req, token).then(resp => {
            dispatch(Actions.setFolderMessages({resp: resp}));
        }).catch((ex) => {
        });
    }
}

export function fetchMessageDetails(req,token) {
    return (dispatch) => {
        return Api.post(types.GET_MESSAGE_DETAILS, req, token).then(resp => {
            dispatch(Actions.setMessageDetails({resp: resp}));
        }).catch((ex) => {
        });
    }
}

export function fetchLiked(req,token) {
    return (dispatch) => {
        return Api.post(types.GET_LIKED, req, token).then(resp => {
            dispatch(Actions.setLiked({resp: resp}));
        }).catch((ex) => {
        });
    }
}

export function fetchAboutUs(req,token) {
    return (dispatch) => {
        return Api.post(types.GET_ABOUT_US, req, token).then(resp => {
            dispatch(Actions.setAboutUs({resp: resp}));
        }).catch((ex) => {
        });
    }
}

export function fetchGallery(req,token) {
    return (dispatch) => {
        return Api.post(types.GET_GALLERY, req, token).then(resp => {
            dispatch(Actions.setGallery({resp: resp}));
        }).catch((ex) => {
        });
    }
}

export function fetchContactUs(req,token) {
    return (dispatch) => {
        return Api.post(types.GET_CONTACT_US, req, token).then(resp => {
            dispatch(Actions.setContactUs({resp: resp}));
        }).catch((ex) => {
        });
    }
}

export function fetchFilter(req,token) {
    return (dispatch) => {
        return Api.post(types.GET_FILTER, req, token).then(resp => {
            dispatch(Actions.setFilter({resp: resp}));
        }).catch((ex) => {
        });
    }
}

export function fetchCategory(req,token) {
    return (dispatch) => {
        return Api.post(types.LOAD_CATEGORY, req, token).then(resp => {
            dispatch(Actions.setCategory({resp: resp}));
        }).catch((ex) => {
        });
    }
}

export function fetchCategoryTypes(req,token) {
    return (dispatch) => {
        return Api.post(types.LOAD_PROGRAMS, req, token).then(resp => {
            dispatch(Actions.setCategoryTypes({resp: resp}));
        }).catch((ex) => {
        });
    }
}

export function fetchRegisterFCM(req,token) {
    return (dispatch) => {
        return Api.post(types.REGISTER_FCM, req, token).then(resp => {
            dispatch(Actions.setRegisterFCM({resp: resp}));
        }).catch((ex) => {
        });
    }
}

export function logout(req,token) {
    return (dispatch) => {
        return Api.post(types.LOGOUT, req, token).then(resp => {
            dispatch(SignOut.setLogout({resp: resp}));
        }).catch((ex) => {
        });
    }
}