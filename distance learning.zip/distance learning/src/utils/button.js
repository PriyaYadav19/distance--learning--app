import React,{Component} from 'react';
import {View, Text ,Button,Alert,Image,Dimensions} from 'react-native';
var {height, width} = Dimensions.get('window');
import {scale, moderateScale, verticalScale} from '../constants/scales'
import * as types from '../constants/actions'


export default class Button1 extends Component{
    render()
    {
        const radius=this.props.radius== null ? scale(2) : this.props.radius;
        //alert(this.props.height)
        return(


            <View style={{backgroundColor:this.props.color,
                //flex:1,
                flexDirection:'row',
                height: this.props.height,
                width:this.props.width,
                marginTop:this.props.marginTop==undefined? scale(10):this.props.marginTop,
                borderRadius: radius,
                alignItems:'center'

            }}>

                <View  style={{
                    flex:1,
                    flexDirection:'column',
                    alignItems:'center'

                }}>
                {this.props.isLoadingButton ?
                    <View style={{alignItems: 'center', backgroundColor: 'rgba(255,255,255,0)'}}>
                        <Image source={require('../img/spinner.gif')}
                               style={{height: scale(21.5),
                                   width: scale(21.5),
                                  // marginTop: scale(16.2)
                               }}>
                        </Image>
                    </View>
                    :
                    <Text style={{
                        fontSize: scale(13.6),
                        color:this.props.txtcolor == undefined ? "#fff" :
                            this.props.txtcolor,
                        //marginTop: scale(16.2),
                        textAlign:'center'
                    }}>{this.props.label}</Text>

                }
                </View>
            </View>

        );
    }
}