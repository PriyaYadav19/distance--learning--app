import React, { Component } from 'react';
import { Modal, Text, TouchableHighlight, View,ScrollView,
    Dimensions,Image,NetInfo,AsyncStorage } from 'react-native';
var {height, width} = Dimensions.get('window');


export function checkConnection() {
    NetInfo.isConnected.fetch().then(async(isConnected) => {
        //alert('inside then='+isConnected)
        await AsyncStorage.setItem('checkNet',isConnected)
    });
}
