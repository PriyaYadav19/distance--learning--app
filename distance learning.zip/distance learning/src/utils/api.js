
import * as types from '../constants/actions'

//var x = 0;
class Api {

    static headers(token) {
        return {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'dataType': 'json',
            'Authorization': 'Bearer ' + token,
            'Package': 'Bearer ' + types.PACKAGE
        }
    }

    static get(route) {
        return this.serviceRequest(route, null, 'GET');
    }

    static post(route, params, token) {
        return this.serviceRequest(route, params, 'POST', token, 0)
    }

    static put(route, params) {
        return this.serviceRequest(route, params, 'PUT')
    }

    static delete(route, params) {
        return this.serviceRequest(route, params, 'DELETE')
    }


    static serviceRequest(route, params, method, token, number) {

        const host = types.BASE_URL
        const url = `${host}${route}`
        let options = Object.assign({method: method}, params ? {body: JSON.stringify(params)} : null);
        options.headers = Api.headers(token)
        //console.log('options ===== >'+JSON.stringify(options.headers))
        return fetch(url, options).then((response) => {

            return response.json().then((resp) => {
                return {response: resp, status: response.status}
            })
        }).then(resp => {
            //console.log(resp)

           // alert("resp"+JSON.stringify(resp))

            return resp


        }).catch((error) => {
            //console.error(error);
            //alert( route+'='+number)
            if (number == 0) {
                console.log(error);

                //return {response: 'error', status: error}
            }
            else {

                number++;
                setTimeout(() => {
                    this.serviceRequest(route, params, method, token, number)
                }, 1000)
            }
            //return {response: {msg: "You are unauthorized to access this feature or the session has timed out."}, status: error};
        });
        //return {status:'error'}


    }
}
export default Api