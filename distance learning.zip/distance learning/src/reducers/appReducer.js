import createReducer from '../utils/createReducer'
import * as types from '../constants/actions'


export const userData = createReducer({}, {
    [types.USER_DATA](state, action) {
        let newState = action.resp;
        return newState;
    }
});

export const getFoldersList = createReducer({}, {
    [types.GET_FOLDER_LIST](state, action) {
        let newState = action.resp;
        return newState;
    }
});

export const test = createReducer({}, {
    [types.TEST](state, action) {
        let newState = action.resp;
        return newState;
    }
})

export const folderMessages = createReducer({}, {
    [types.GET_FOLDER_MESSAGES](state, action) {
        let newState = action.resp;
        return newState;
    }
});

export const messageDetails = createReducer({}, {
    [types.GET_MESSAGE_DETAILS](state, action) {
        let newState = action.resp;
        return newState;
    }
});

export const getNavigation = createReducer({}, {
    [types.STORED_NAVIGATION](state, action) {
        let newState = action.resp;
        return newState;
    }
});

export const liked = createReducer({}, {
    [types.GET_LIKED](state, action) {
        let newState = action.resp;
        return newState;
    }
});

export const aboutUs = createReducer({}, {
    [types.GET_ABOUT_US](state, action) {
        let newState = action.resp;
        return newState;
    }
});

export const gallery = createReducer({}, {
    [types.GET_GALLERY](state, action) {
        let newState = action.resp;
        return newState;
    }
});

export const contactUs = createReducer({}, {
    [types.GET_CONTACT_US](state, action) {
        let newState = action.resp;
        return newState;
    }
});

export const filter = createReducer({}, {
    [types.GET_FILTER](state, action) {
        let newState = action.resp;
        return newState;
    }
});

export const category = createReducer({}, {
    [types.LOAD_CATEGORY](state, action) {
        let newState = action.resp;
        return newState;
    }
});

export const categorytypes = createReducer({}, {
    [types.LOAD_PROGRAMS](state, action) {
        let newState = action.resp;
        return newState;
    }
});

export const fcm = createReducer({}, {
    [types.REGISTER_FCM](state, action) {
        let newState = action.resp;
        return newState;
    }
});