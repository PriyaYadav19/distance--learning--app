import { combineReducers } from 'redux';
import * as Reducer from './appReducer'
import * as types from '../constants/actions'


export const appReducer = combineReducers(Object.assign(
    Reducer
));


export const rootReducer = (state, action) => {

    if (action.type === types.USER_LOGOUT) {
        state = undefined
    }

    return appReducer(state, action)
}

