/*
 * React Native Meeting App
 * navigation.js
 * ATSPL
 */

import React from 'react';
import {Dimensions, Easing, Animated} from 'react-native';
import { createAppContainer } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
import Dashboard from '../components/dashboard'
import TabBar from '../components/tabBar'
var {height, width} = Dimensions.get('window');
import Ebook from '../components/Ebook'
import Syllabus from '../components/syllabus'
import Events from '../components/Events'
import Fees from '../components/Fees'
import  Calendar from  '../components/calender'
import Login from '../components/login'
import SignIn from '../components/signIn';
import Signup from '../components/signup';
const NaviAppStack = createStackNavigator({

    Dashboard:Dashboard,
    TabBar:TabBar,
    Ebook:Ebook,
    Fees:Fees,
Events:Events,
    Login:Login,

    Calendar:Calendar,
    Syllabus:Syllabus,
    SignIn:SignIn,
    Signup:Signup,
},{
    initialRouteName: "Dashboard"

});


/*const NaviApp=createDrawerNavigator({
        homedrawer: {
            screen: NaviAppStack,
        },
    },Dashboard
    {
        drawerOpenRoute: 'DrawerOpen',
        drawerCloseRoute: 'DrawerClose',
        drawerToggleRoute: 'DrawerToggle',
        drawerLockMode:'locked-closed',
        contentComponent: Drawer1
    }

);*/


export default createAppContainer(NaviAppStack);

