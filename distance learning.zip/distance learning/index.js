/**
 * @format
 */

/*
import {AppRegistry} from 'react-native';
import App from './App';
import {name as appName} from './app.json';

AppRegistry.registerComponent(appName, () => App);
*/
/**
 * @format
 */
import React ,{Component,}from 'react'
import {AppRegistry,Platform,StatusBar,View} from 'react-native';
//import App from './App';
import {name as appName} from './app.json';
import { Provider } from 'react-redux'
import { createStore,applyMiddleware,compose} from 'redux'
import * as reducer from './src/reducers'
import thunkMiddleware from 'redux-thunk'
import {createLogger} from 'redux-logger'
import NaviApp from './src/navigation/navigation'
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux'
import { ActionCreators } from './src/constants/actions'
import {NavigationActions,StackActions} from 'react-navigation';

const loggerMiddleware = createLogger({ predicate: (getState, action) => __DEV__  });

function configureStore(initialState) {
    const enhancer = compose(
        applyMiddleware(
            thunkMiddleware,
            loggerMiddleware,
        ),
    );
    return createStore(reducer.rootReducer, initialState, enhancer);
}

export const store = configureStore({});

export default class App extends Component {
    componentWillMount(){

    }

  render() {
        return (
            <Provider store={ store }>
                <View style={{flex:1}}>
                    {
                        Platform.OS=='android'?
                            <StatusBar
                                backgroundColor={"#520303"}
                                barStyle="light-content"
                            />
                            :null
                    }
                    <NaviApp />
                </View>
            </Provider>
        )
    }
}



AppRegistry.registerComponent(appName, () => App);
